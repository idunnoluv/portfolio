from django.urls import path
from APM import views

urlpatterns = [
    path ('', views.index, name = 'index')
]
