from django.http import HttpRequest, HttpResponse
from django.shortcuts import render, redirect

def index(request: HttpRequest) -> HttpResponse:
    data = {

    }
    return render(request, 'index.html', data)