from django.db import models

class StandardModel(models.Model):
    """Model definition for StandardModel"""
    statut = models.BooleanField(default=True)
    date_add = models.DateTimeField(auto_now_add=True)
    date_upd = models.DateTimeField(auto_now=True)

    class Meta:
        """Meta definition for StandardModel"""
        abstract = True


class PersonalInfo(StandardModel):
    email = models.EmailField(max_length= 120)
    birthday = models.DateField(auto_now=False, auto_now_add=False)
    location = models.CharField(max_length=20)
    numero = models.CharField(max_length=10)

    

    # TODO: Define fields here

    class Meta:
        """Meta definition for Personal_Info."""

        verbose_name =  'PersonalInfo'
        verbose_name_plural =  'PersonalInfos'

    def __str__(self):
        """Unicode representation of Personal_Info."""
        return self.location
